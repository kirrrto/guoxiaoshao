import { useState } from "react"
import { Check, Moon, Sun } from "lucide-react"

import { useTheme } from "@/components/theme-provider"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"

export function App() {
  const { setTheme } = useTheme()
  const [memory, setMemory] = useState("16 GB")
  const [store, setStore] = useState("上海")
  const [saved, setSaved] = useState(false)
  const [invalid, setInvalid] = useState(false)

  return (
    <main className="mx-auto min-h-svh max-w-5xl px-5 py-8 sm:px-8 sm:py-12">
      <header className="mb-10 flex items-start justify-between gap-4 border-b pb-6">
        <div className="min-w-0">
          <p className="mb-2 text-sm font-medium text-foreground">
            果小哨 · 组件参照
          </p>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
            选择、状态与反馈
          </h1>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground">
            shadcn/create 实际生成的独立 Web
            样页；操作仅在本页演示，不连接业务服务。
          </p>
        </div>
        <Button
          variant="outline"
          size="icon-lg"
          className="min-h-11 min-w-11"
          aria-label="切换明暗主题"
          onClick={() =>
            setTheme(
              document.documentElement.classList.contains("dark")
                ? "light"
                : "dark"
            )
          }
        >
          <Sun className="hidden dark:block" aria-hidden="true" />
          <Moon className="dark:hidden" aria-hidden="true" />
        </Button>
      </header>

      <div className="grid items-start gap-8 md:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <Card className="gap-6">
          <CardHeader>
            <CardTitle>
              <h2>选择配置</h2>
            </CardTitle>
          </CardHeader>
          <form
            onSubmit={(event) => {
              event.preventDefault()
              const missing = !store.trim()
              setInvalid(missing)
              setSaved(!missing)
            }}
          >
            <CardContent className="gap-6">
              <div className="flex items-baseline justify-between gap-3">
                <p className="text-xl font-medium">iMac</p>
                <Badge variant="outline">配置示例</Badge>
              </div>
              <fieldset className="min-w-0">
                <legend className="mb-3 text-sm font-medium">统一内存</legend>
                <div className="grid grid-cols-2 gap-3">
                  {["16 GB", "24 GB"].map((value) => (
                    <Button
                      key={value}
                      type="button"
                      variant={memory === value ? "default" : "outline"}
                      className="min-h-12"
                      aria-pressed={memory === value}
                      onClick={() => {
                        setMemory(value)
                        setSaved(false)
                      }}
                    >
                      {memory === value && <Check aria-hidden="true" />}
                      {value}
                    </Button>
                  ))}
                </div>
              </fieldset>
              <div className="space-y-3">
                <label htmlFor="store" className="block text-sm font-medium">
                  城市或门店
                </label>
                <Input
                  id="store"
                  value={store}
                  className="min-h-11"
                  placeholder="输入城市或门店"
                  aria-invalid={invalid}
                  aria-describedby={invalid ? "store-error" : undefined}
                  onChange={(event) => {
                    setStore(event.target.value)
                    setInvalid(false)
                    setSaved(false)
                  }}
                />
                {invalid && (
                  <p
                    id="store-error"
                    role="alert"
                    className="text-sm text-destructive"
                  >
                    请输入城市或门店。
                  </p>
                )}
              </div>
            </CardContent>
            <CardFooter className="mt-6 flex-col items-stretch gap-3 border-t pt-6">
              <Button type="submit" className="min-h-11">
                保存示例
              </Button>
              <p
                role="status"
                className="min-h-5 text-sm text-muted-foreground"
              >
                {saved
                  ? `已保存：iMac · ${memory} · ${store.trim()}`
                  : "选择后保存，即可查看反馈。"}
              </p>
            </CardFooter>
          </form>
        </Card>

        <div className="space-y-8">
          <section aria-labelledby="buttons-heading">
            <h2 id="buttons-heading" className="mb-4 text-base font-medium">
              操作层级
            </h2>
            <div className="flex flex-wrap gap-3">
              <Button
                className="min-h-11"
                onClick={() => {
                  setMemory("16 GB")
                  setStore("上海")
                  setInvalid(false)
                  setSaved(false)
                }}
              >
                重置示例
              </Button>
              <Button
                variant="outline"
                className="min-h-11"
                onClick={() => {
                  setStore("")
                  setInvalid(false)
                  setSaved(false)
                }}
              >
                清空输入
              </Button>
              <Button disabled className="min-h-11">
                暂不可用
              </Button>
            </div>
          </section>

          <section aria-labelledby="status-heading" className="border-t pt-6">
            <h2 id="status-heading" className="mb-4 text-base font-medium">
              状态样式
            </h2>
            <div className="flex flex-wrap gap-3">
              <Badge>已保存</Badge>
              <Badge variant="secondary">待更新</Badge>
              <Badge variant="destructive">保存失败</Badge>
              <Badge variant="outline">已暂停</Badge>
            </div>
          </section>

          <section
            aria-labelledby="input-heading"
            className="space-y-3 border-t pt-6"
          >
            <h2 id="input-heading" className="mb-4 text-base font-medium">
              输入状态
            </h2>
            <label htmlFor="input-error" className="block text-sm">
              错误示例
            </label>
            <Input
              id="input-error"
              className="min-h-11"
              defaultValue="未匹配的门店"
              aria-invalid="true"
              aria-describedby="input-error-description"
            />
            <p
              id="input-error-description"
              className="text-sm text-destructive"
            >
              未找到门店，请检查名称。
            </p>
            <label htmlFor="input-disabled" className="block pt-2 text-sm">
              禁用示例
            </label>
            <Input
              id="input-disabled"
              className="min-h-11"
              value="暂不可编辑"
              disabled
            />
          </section>
        </div>
      </div>

      <footer className="mt-12 border-t pt-5 text-xs leading-relaxed text-muted-foreground">
        <p>Preset b2BnwlLhw · Vega / Neutral / Emerald · shadcn 4.23.0</p>
        <p className="mt-1">
          Web
          参照保留预设字体和颜色；小程序继续使用既有中文系统字体、主绿与原生入口。
        </p>
      </footer>
    </main>
  )
}

export default App
