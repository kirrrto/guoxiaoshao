# 果小哨 shadcn/create 独立参照

2026-10-28 实际执行 shadcn 4.23.0，预设 `b2BnwlLhw`，Vite 模板。官方生成的 Button、Card、Input、Badge 与主题 CSS 保留在 `src`；`App.tsx` 是用于核对选中、禁用、错误、保存反馈与明暗主题的本地示例。没有业务服务或小程序运行时。

字体由 `src/index.css` 导入 `@fontsource-variable/noto-sans`，实际字体文件来自锁文件固定的 npm 依赖。源码归档保留导入、主题和锁文件，不包含 `node_modules`、`dist` 或 `.git`。

使用 Node 24.22.1，在新的独立目录解压后执行：

```powershell
node --version
npm ci
npm run build
npm run preview -- --host 127.0.0.1 --port 4179 --strictPort
```

`node --version` 应为 `v24.22.1`；`npm ci` 需要访问锁文件中记录的官方 npm 包源。只在解压目录安装依赖，不在果小哨项目根目录初始化。预览仅供本地核对，完成后按 Ctrl+C 关闭。

原始生成命令的固定版本形式：

```powershell
npx --yes shadcn@4.23.0 init --preset b2BnwlLhw --template vite --name shadcn-reference --no-monorepo --yes
```

解压源码已经包含生成结果，复现样页只需 `npm ci` 和 build，不需再次 init。完整命令、版本、63 个主题变量对照、源文件与产物 SHA256 位于同批证据 `shadcn-cli-verification.json`；真实浏览器截图与交互记录单独保存。全文件 CSS 哈希不同不代表主题变量不同：生成项目还包含 imports、Tailwind 映射和基础层。

浅深色检查中，页眉原先误用了 `text-primary`，已改为 `text-foreground`；63 个官方主题变量未改动。小程序只参考层级、成对语义色和状态组织，继续保留既有主绿、中文系统字体、四个原生入口与精确 SKU。
